<?php 
	/** config your app id here */
const ZALO_APP_ID_CFG = "2059683139369741448";
    
/** config your app secret key here */
const ZALO_APP_SECRET_KEY_CFG = "xdKBtIb1CgbRn1WrpkVI";

/** config your offical account id here */
const ZALO_OA_ID_CFG = "3136165591071614747";

/** config your offical account secret key here */
const ZALO_OA_SECRET_KEY_CFG = "UjEy5XLEMPB0ZrQAb65P";
?>